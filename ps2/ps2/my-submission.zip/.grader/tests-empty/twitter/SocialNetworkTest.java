package twitter;

public class SocialNetworkTest {
}
